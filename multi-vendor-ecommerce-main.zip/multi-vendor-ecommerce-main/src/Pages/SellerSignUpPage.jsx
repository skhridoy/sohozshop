import React from "react";
import SignupNewSeller from "../Components/Layout/Seller/SignupNewSeller";

const SellerSignUpPage = () => {
  return (
    <>
      <SignupNewSeller />
    </>
  );
};

export default SellerSignUpPage;
